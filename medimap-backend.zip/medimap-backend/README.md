# MediMap backend

Real-time hospital capacity system: Express API, Socket.IO live push, JWT staff login, JSON-file database, and the patient/staff frontend in `public/`.

## Run it (needs Node.js 18+)

```bash
npm install
npm start
```

Open http://localhost:3000

## Demo it to judges

1. Open http://localhost:3000 in two windows (or one on your phone using your laptop's IP, same Wi-Fi).
2. In window 2, open the "Hospital desk" tab and sign in: username `citycare`, password `demo123`.
3. Change ICU beds, press "Publish update".
4. Window 1 updates instantly with no refresh, and the freshness stamp resets to "just now".

Other usernames: stjude, lotus, apex, riverside, sunrise, metro, greenvalley.

## API

| Method | Path | Auth | What it does |
|---|---|---|---|
| POST | /api/login | none | `{username, password}` returns a JWT |
| GET | /api/hospitals | none | All hospitals with free/total beds |
| GET | /api/hospitals/:id/history | none | Last 50 bed updates |
| PUT | /api/hospitals/:id/beds | Bearer JWT | Staff updates free beds, e.g. `{"icu": 5}` |

Socket.IO event `hospital:update` is sent to all clients after every update.

## Config (environment variables)

- `PORT` (default 3000)
- `JWT_SECRET` (set this for any real deployment)
- `DEMO_PASSWORD` (default demo123)

## Deploy (optional)

Push this folder to GitHub, then create a Web Service on Render or Railway with build command `npm install` and start command `npm start`. Set `JWT_SECRET` there.

## Notes

- Data is simulated. A production version would connect to hospital HIS systems and use a real database (PostgreSQL or Mongo), as in your architecture slide.
- Data is saved in `data/db.json`. Delete that file to reset to the seed data.
