// Demo seed data. Beds are [free, total]. Replace with real HIS feeds later.
const h = (id, slug, name, x, y, km, min, tags, spec, phone, gen, icu, ped, vent) => ({
  id, slug, name, x, y, km, min, tags, spec, phone,
  beds: { gen, icu, ped, vent },
  updatedAt: Date.now(),
  history: []
});

module.exports = [
  h(1, "citycare", "City Care Hospital", 42, 30, 1.8, 6, ["Trauma Level 1", "24/7 oxygen"], ["Trauma surgeon", "Neurologist"], "+911100000001", [48,120], [14,40], [9,24], [6,16]),
  h(2, "stjude", "St. Jude Medical Center", 63, 22, 3.4, 11, ["Cardiac"], ["Cardiologist", "Cardiac surgeon"], "+911100000002", [12,90], [3,22], [4,18], [2,10]),
  h(3, "lotus", "Lotus Children’s Hospital", 30, 48, 4.1, 14, ["Pediatric"], ["Pediatric intensivist"], "+911100000003", [31,60], [5,12], [18,40], [3,8]),
  h(4, "apex", "Apex Super Speciality", 74, 46, 5.6, 17, ["Trauma Level 1", "Cardiac"], ["Cardiologist", "Trauma surgeon"], "+911100000004", [70,200], [2,36], [7,20], [1,14]),
  h(5, "riverside", "Riverside General", 20, 24, 6.2, 21, ["24/7 oxygen"], ["General surgeon"], "+911100000005", [55,150], [9,28], [6,16], [4,12]),
  h(6, "sunrise", "Sunrise Heart Institute", 56, 56, 6.9, 19, ["Cardiac"], ["Cardiologist"], "+911100000006", [18,70], [4,18], [0,10], [3,9]),
  h(7, "metro", "Metro Emergency Care", 84, 24, 8.3, 26, ["Trauma Level 1"], ["Trauma surgeon", "Anaesthetist"], "+911100000007", [26,80], [0,16], [2,12], [0,6]),
  h(8, "greenvalley", "Green Valley Hospital", 12, 58, 9.1, 31, ["24/7 oxygen"], ["Physician"], "+911100000008", [40,100], [8,20], [11,20], [5,10])
];
