const path = require("path");
const fs = require("fs");
const http = require("http");
const crypto = require("crypto");
const express = require("express");
const jwt = require("jsonwebtoken");
const { Server } = require("socket.io");
const seed = require("./seed");

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "change-me-before-deploying";
const DEMO_PASSWORD = process.env.DEMO_PASSWORD || "demo123";
const DB_FILE = path.join(__dirname, "data", "db.json");
const BED_KEYS = ["gen", "icu", "ped", "vent"];

/* ---------- tiny JSON-file database ---------- */
function loadDb() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return JSON.parse(JSON.stringify(seed)); }
}
let hospitals = loadDb();
let saveTimer = null;
function persist() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => fs.writeFile(DB_FILE, JSON.stringify(hospitals, null, 2), () => {}), 200);
}
persist();

const publicView = (h) => ({
  id: h.id, name: h.name, x: h.x, y: h.y, km: h.km, min: h.min,
  tags: h.tags, spec: h.spec, phone: h.phone, beds: h.beds, updatedAt: h.updatedAt
});

/* ---------- staff accounts: one per hospital (demo) ---------- */
// username = hospital slug (e.g. "citycare"), password = DEMO_PASSWORD
const hash = (s) => crypto.createHash("sha256").update(s).digest();
const safeEq = (a, b) => crypto.timingSafeEqual(hash(a), hash(b));

/* ---------- app ---------- */
const app = express();
const server = http.createServer(app);
const io = new Server(server);
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

// naive login rate limit: 10 tries per minute per IP
const attempts = new Map();
function limited(ip) {
  const now = Date.now();
  const list = (attempts.get(ip) || []).filter((t) => now - t < 60000);
  list.push(now);
  attempts.set(ip, list);
  return list.length > 10;
}

function auth(req, res, next) {
  const token = (req.headers.authorization || "").replace(/^Bearer /, "");
  try { req.user = jwt.verify(token, JWT_SECRET); next(); }
  catch { res.status(401).json({ error: "Sign in again: your session is missing or expired." }); }
}

app.post("/api/login", (req, res) => {
  if (limited(req.ip)) return res.status(429).json({ error: "Too many attempts. Wait a minute and try again." });
  const { username = "", password = "" } = req.body || {};
  const h = hospitals.find((x) => x.slug === String(username).trim().toLowerCase());
  if (!h || !safeEq(String(password), DEMO_PASSWORD))
    return res.status(401).json({ error: "Wrong username or password." });
  const token = jwt.sign({ role: "staff", hospitalId: h.id }, JWT_SECRET, { expiresIn: "8h" });
  res.json({ token, hospital: publicView(h) });
});

app.get("/api/hospitals", (_req, res) => res.json(hospitals.map(publicView)));

app.get("/api/hospitals/:id/history", (req, res) => {
  const h = hospitals.find((x) => x.id === +req.params.id);
  if (!h) return res.status(404).json({ error: "Hospital not found." });
  res.json(h.history.slice(-50));
});

// Staff update: body like { "gen": 40, "icu": 5 }. Values are FREE beds.
app.put("/api/hospitals/:id/beds", auth, (req, res) => {
  const id = +req.params.id;
  if (req.user.hospitalId !== id)
    return res.status(403).json({ error: "You can only update your own hospital." });
  const h = hospitals.find((x) => x.id === id);
  if (!h) return res.status(404).json({ error: "Hospital not found." });

  const body = req.body || {};
  const next = {};
  for (const k of BED_KEYS) {
    if (body[k] === undefined) continue;
    const v = body[k];
    if (!Number.isInteger(v) || v < 0 || v > h.beds[k][1])
      return res.status(400).json({ error: `${k} must be a whole number from 0 to ${h.beds[k][1]}.` });
    next[k] = v;
  }
  if (!Object.keys(next).length) return res.status(400).json({ error: "Send at least one of: gen, icu, ped, vent." });

  for (const k of Object.keys(next)) h.beds[k][0] = next[k];
  h.updatedAt = Date.now();
  h.history.push({ at: h.updatedAt, free: Object.fromEntries(BED_KEYS.map((k) => [k, h.beds[k][0]])) });
  if (h.history.length > 200) h.history.shift();
  persist();

  io.emit("hospital:update", publicView(h)); // push to every open patient screen
  res.json(publicView(h));
});

io.on("connection", (socket) => socket.emit("hello", { hospitals: hospitals.length }));

server.listen(PORT, () => {
  console.log(`MediMap running at http://localhost:${PORT}`);
  console.log(`Staff login: username = hospital slug (e.g. citycare), password = ${DEMO_PASSWORD}`);
});
